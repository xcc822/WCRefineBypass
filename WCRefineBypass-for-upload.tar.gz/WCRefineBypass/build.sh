#!/bin/bash

# WCRefineBypass 自动编译脚本

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}=== WCRefineBypass Build Script ===${NC}"

# 检查 theos
if [ -z "$THEOS" ]; then
    echo -e "${YELLOW}Warning: THEOS environment variable not set${NC}"
    echo "Using default: ~/theos"
    export THEOS=~/theos
fi

if [ ! -d "$THEOS" ]; then
    echo -e "${RED}Error: theos not found at $THEOS${NC}"
    echo "Please install theos first: https://theos.dev/docs/installation"
    exit 1
fi

echo -e "${GREEN}[1/4] Cleaning...${NC}"
rm -rf .theos
rm -rf packages

echo -e "${GREEN}[2/4] Building...${NC}"
make clean
make

echo -e "${GREEN}[3/4] Packaging...${NC}"
make package

echo -e "${GREEN}[4/4] Done!${NC}"

# 查找生成的 deb
DEB_FILE=$(ls -t packages/*.deb 2>/dev/null | head -1)
if [ -n "$DEB_FILE" ]; then
    echo -e "${GREEN}Package created: $DEB_FILE${NC}"
    
    # 复制到预编译目录
    cp "$DEB_FILE" ./
    echo -e "${GREEN}Copied to: $(basename $DEB_FILE)${NC}"
else
    echo -e "${YELLOW}Warning: .deb file not found in packages/${NC}"
fi

echo ""
echo "Install options:"
echo "  1. make install          (if device is connected)"
echo "  2. Copy .deb to device and install via Filza/Sileo"
echo "  3. scp .deb root@device-ip:/tmp && ssh root@device-ip 'dpkg -i /tmp/*.deb'"
