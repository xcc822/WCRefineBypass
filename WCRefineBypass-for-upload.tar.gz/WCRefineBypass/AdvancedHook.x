// ==================== 构造函数中的运行时修改 ====================

// 使用 MSHookMessageEx 进行更底层的 hook
#include <substrate.h>

static BOOL (*orig_hasUnlockedSuccessfully)(id, SEL);
static BOOL new_hasUnlockedSuccessfully(id self, SEL _cmd) {
    NSLog(@"[WCRefineBypass] MSHook hasUnlockedSuccessfully called");
    return YES;
}

static BOOL (*orig_hasSponsored)(id, SEL);
static BOOL new_hasSponsored(id self, SEL _cmd) {
    NSLog(@"[WCRefineBypass] MSHook hasSponsored called");
    return YES;
}

// 在 %ctor 中添加
static void hookWithMSHook() {
    Class authClass = NSClassFromString(@"WCRefineAuth");
    if (authClass) {
        MSHookMessageEx(
            authClass,
            @selector(hasUnlockedSuccessfully),
            (IMP)&new_hasUnlockedSuccessfully,
            (IMP *)&orig_hasUnlockedSuccessfully
        );
        
        MSHookMessageEx(
            authClass,
            @selector(hasSponsored),
            (IMP)&new_hasSponsored,
            (IMP *)&orig_hasSponsored
        );
        
        NSLog(@"[WCRefineBypass] MSHook installed for WCRefineAuth");
    }
}
