# 🚀 GitHub Actions 编译指南（超简单版）

## 一句话说明
> 把代码传 GitHub → 自动编译 → 下载 .deb → 安装到手机

---

## 📋 详细步骤（5 分钟搞定）

### ① 下载项目文件
下载这个压缩包: [WCRefineBypass-完整版.tar.gz](minis://workspace/WCRefineBypass-完整版.tar.gz)

解压后你会看到：
```
WCRefineBypass/
├── Tweak.x              ← 源代码
├── Makefile
├── .github/workflows/   ← GitHub Actions 配置
└── ...其他文件
```

---

### ② 上传到 GitHub

#### 方式 A：网页上传（最简单）

1. 打开 [github.com/new](https://github.com/new) 创建新仓库
2. 仓库名填 `WCRefineBypass`
3. 选择 **Public**（公开）
4. ❌ 不要勾选 "Add a README file"
5. 点击 **Create repository**
6. 在新页面点击 **uploading an existing file**
7. 把解压后的文件全部拖进去
8. 点击 **Commit changes**

#### 方式 B：命令行（如果你有 git）

```bash
cd WCRefineBypass
./upload_to_github.sh 你的GitHub用户名
```

---

### ③ 触发编译

1. 打开你的仓库页面
2. 点击顶部的 **Actions** 标签
3. 点击左侧的 **Build WCRefineBypass**
4. 点击右侧绿色按钮 **Run workflow** → **Run workflow**

```
┌─────────────────────────────────────────┐
│  Actions 标签                            │
│  ┌─────────────────────────────────────┐ │
│  │ Build WCRefineBypass                │ │ ← 点这个
│  │ ┌─────────────────────────────────┐ │ │
│  │ │ This workflow has a...         │ │ │
│  │ │ [Run workflow ▼] [Run workflow] │ │ │ ← 再点这个
│  │ └─────────────────────────────────┘ │ │
│  └─────────────────────────────────────┘ │
└─────────────────────────────────────────┘
```

---

### ④ 等待编译完成

- ⏱️ 大概 2-3 分钟
- 你会看到一个黄色圆点在转 → 变成绿色 ✅

---

### ⑤ 下载编译好的文件

1. 点击完成的工作流（绿色 ✅）
2. 滚动到页面底部
3. 看到 **Artifacts** 区域
4. 点击 **WCRefineBypass-deb** 下载

解压后得到：
```
WCRefineBypass_1.0.0_iphoneos-arm64.deb
```

---

### ⑥ 安装到手机

#### 方法 1：用 Filza（最简单）
1. 把 .deb 传到手机（AirDrop/微信/QQ）
2. 用 Filza 打开
3. 点击安装
4. 注销 SpringBoard

#### 方法 2：命令行
```bash
scp WCRefineBypass_*.deb root@手机IP:/tmp/
ssh root@手机IP "dpkg -i /tmp/WCRefineBypass_*.deb && killall -9 SpringBoard"
```

---

## 🎉 完成！

打开微信，WCRefine 应该已经解锁所有功能了。

---

## ❓ 常见问题

### Q: Actions 按钮是灰色的？
**A:** 检查 `.github/workflows/build.yml` 是否在正确位置。必须是：
```
.github/workflows/build.yml
```
不是：
```
WCRefineBypass/.github/workflows/build.yml
```

### Q: 编译失败了？
**A:** 点击红色的 ❌ 查看错误，通常是文件位置不对。

### Q: 下载的 zip 里没有 .deb？
**A:** 检查 workflow 是否成功完成（绿色 ✅）

---

## 🔥 视频教程

如果你觉得文字看不懂，可以看这个流程：

```
上传代码 → 等待 3 分钟 → 下载 .deb → 安装 → 搞定！
   ↑                                           ↓
   └──────── 想更新？直接修改代码再上传 ─────────┘
```

---

**有问题随时问我！** 😊
