#!/bin/bash
# 编译脚本 - 检测环境并编译

set -e

THEOS_PATH="${THEOS:-$HOME/theos}"
PROJECT_NAME="WCRefineBypass"

echo "=== $PROJECT_NAME Build Script ==="

# 检查是否有 theos
if [ ! -d "$THEOS_PATH" ]; then
    echo "[+] Installing theos..."
    bash -c "$(curl -fsSL https://raw.githubusercontent.com/theos/theos/master/bin/install-theos)"
fi

export THEOS=$THEOS_PATH

echo "[+] Cleaning..."
make clean

echo "[+] Building..."
make package FINALPACKAGE=1

echo "[+] Done!"
echo ""
echo "输出文件:"
ls -la packages/*.deb 2>/dev/null || echo "未找到 .deb 包"
