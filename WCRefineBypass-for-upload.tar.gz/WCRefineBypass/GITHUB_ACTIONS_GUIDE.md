# GitHub Actions 使用指南

## 🚀 快速开始（3 步搞定）

### 第 1 步：Fork 仓库

1. 打开你的 GitHub 账号
2. 创建新仓库：`WCRefineBypass`
3. 或者 Fork 现成的（如果有）

### 第 2 步：上传代码

把你刚才下载的文件上传到仓库：

```bash
# 方式1：命令行（如果你会用 git）
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/你的用户名/WCRefineBypass.git
git push -u origin main

# 方式2：网页上传
# 1. 打开 https://github.com/你的用户名/WCRefineBypass
# 2. 点击 "Add file" → "Upload files"
# 3. 拖拽所有文件，点击 "Commit changes"
```

### 第 3 步：运行 Actions

1. 打开仓库页面，点击顶部的 **Actions** 标签
2. 点击左侧的 **Build WCRefineBypass**
3. 点击右侧的 **Run workflow** 按钮
4. 确认分支是 `main`，点击绿色的 **Run workflow**

![运行示意图]

等待 2-3 分钟...

### 第 4 步：下载 .deb

编译完成后：

1. 进入 Actions 页面，点击最新的 workflow run
2. 滚动到底部的 **Artifacts** 区域
3. 点击 **WCRefineBypass-deb** 下载
4. 解压得到 .deb 文件

---

## 📦 自动发布 Release（可选）

如果你想每次推送代码都自动发布 Release：

### 创建 Release

1. 进入仓库的 **Releases** 页面
2. 点击 **Create a new release**
3. 输入标签名，如 `v1.0.0`
4. 点击 **Publish release**
5. Actions 会自动编译并上传 .deb 到 Release

---

## 🔧 常见问题

### Q: Actions 运行失败？

检查以下几点：

1. **文件是否在根目录？**
   - `Makefile`、`Tweak.x`、`control` 等必须在仓库根目录
   - 不能放在子文件夹里

2. **检查文件是否上传完整**
   ```bash
   # 应该包含这些文件
   - .github/workflows/build.yml
   - Makefile
   - Tweak.x
   - control
   - WCRefineBypass.plist
   ```

3. **查看错误日志**
   - 点击失败的 workflow
   - 点击红色的 ❌ 查看具体错误

### Q: 如何修改编译目标？

编辑 `Makefile`：

```makefile
# 修改 iOS 版本
TARGET := iphone:clang:latest:15.0  # 改为 15.0

# 修改架构（如果只需要 arm64）
ARCHS = arm64
```

### Q: 如何添加自己的代码？

直接修改 `Tweak.x`，然后 push 到 GitHub，Actions 会自动重新编译。

---

## 📱 安装到 iOS 设备

### 方式 1：直接安装（需要越狱）

```bash
# 把 .deb 传到设备
scp WCRefineBypass_*.deb root@你的设备IP:/tmp/

# SSH 到设备安装
ssh root@你的设备IP

# 安装
dpkg -i /tmp/WCRefineBypass_*.deb

# 重启 SpringBoard
killall -9 SpringBoard
```

### 方式 2：用 Filza/Sileo

1. 把 .deb 传到设备（AirDrop/微信/QQ）
2. 用 Filza 打开
3. 点击安装
4. 注销或重启设备

### 方式 3：添加到源

如果你想让别人也能下载：

1. 创建一个 `Packages` 文件
2. 上传到 GitHub Pages 或其他托管
3. 在 Sileo/Zebra 里添加源

---

## 🎯 完整流程图

```
上传代码 → GitHub Actions 编译 → 下载 .deb → 安装到设备 → 享受插件
   ↑                                              ↓
   └──────────── 修改代码重新上传 ←───────────────┘
```

---

## 💡 提示

- **首次编译**可能需要 3-5 分钟（要下载 SDK）
- **后续编译**只需要 1-2 分钟（有缓存）
- 如果你想测试不同代码，可以直接在 GitHub 网页上编辑 `Tweak.x`，保存后自动触发编译

---

## 🆘 需要帮助？

如果还是搞不定，可以：

1. 发 Issues 到仓库
2. 提供 workflow 的错误日志
3. 或者直接问小美我 😊
