// WCRefine 验证绕过 Tweak
// Hook 验证相关方法和属性

#import <substrate.h>
#import <Foundation/Foundation.h>

// ==================== 关键类声明 ====================

@interface WCRefineAuth : NSObject
+ (instancetype)sharedInstance;
- (BOOL)hasUnlockedSuccessfully;
- (void)setHasUnlockedSuccessfully:(BOOL)unlocked;
- (BOOL)hasSponsored;
- (void)setHasSponsored:(BOOL)sponsored;
- (BOOL)biometricUnlockEnabled;
- (BOOL)checkAuth;
- (BOOL)isValid;
- (void)verifyWithCompletion:(id)completion;
@end

@interface WCRefineManager : NSObject
+ (instancetype)sharedManager;
- (BOOL)isFeatureUnlocked:(NSString *)feature;
- (BOOL)hasValidLicense;
- (BOOL)checkLicenseStatus;
@end

// ==================== WCRefineAuth Hook ====================

%hook WCRefineAuth

// 强制返回已解锁
- (BOOL)hasUnlockedSuccessfully {
    NSLog(@"[WCRefineBypass] hasUnlockedSuccessfully hooked - returning YES");
    return YES;
}

// 强制设置解锁状态
- (void)setHasUnlockedSuccessfully:(BOOL)unlocked {
    NSLog(@"[WCRefineBypass] setHasUnlockedSuccessfull called with %d, forcing YES", unlocked);
    %orig(YES);
}

// 强制返回已赞助
- (BOOL)hasSponsored {
    NSLog(@"[WCRefineBypass] hasSponsored hooked - returning YES");
    return YES;
}

- (void)setHasSponsored:(BOOL)sponsored {
    NSLog(@"[WCRefineBypass] setHasSponsored called with %d, forcing YES", sponsored);
    %orig(YES);
}

// 生物识别解锁强制启用
- (BOOL)biometricUnlockEnabled {
    return YES;
}

// 验证方法直接返回成功
- (BOOL)checkAuth {
    NSLog(@"[WCRefineBypass] checkAuth hooked - returning YES");
    return YES;
}

- (BOOL)isValid {
    NSLog(@"[WCRefineBypass] isValid hooked - returning YES");
    return YES;
}

// 拦截验证请求，直接调用成功回调
- (void)verifyWithCompletion:(id)completion {
    NSLog(@"[WCRefineBypass] verifyWithCompletion intercepted");
    if (completion) {
        // 创建成功结果字典
        NSDictionary *fakeResponse = @{
            @"success": @YES,
            @"code": @200,
            @"message": @"验证成功",
            @"data": @{
                @"valid": @YES,
                @"expired": @NO,
                @"vip": @YES,
                @"sponsored": @YES
            }
        };
        
        // 异步回调成功
        dispatch_async(dispatch_get_main_queue(), ^{
            if ([completion isKindOfClass:NSClassFromString(@"NSBlock")]) {
                // 假设是 block 回调，尝试调用
                void (^block)(id) = (void (^)(id))completion;
                block(fakeResponse);
            }
        });
    }
}

%end

// ==================== WCRefineManager Hook ====================

%hook WCRefineManager

- (BOOL)isFeatureUnlocked:(NSString *)feature {
    NSLog(@"[WCRefineBypass] isFeatureUnlocked:%@ - returning YES", feature);
    return YES;
}

- (BOOL)hasValidLicense {
    NSLog(@"[WCRefineBypass] hasValidLicense hooked - returning YES");
    return YES;
}

- (BOOL)checkLicenseStatus {
    NSLog(@"[WCRefineBypass] checkLicenseStatus hooked - returning YES");
    return YES;
}

%end

// ==================== 通用属性Hook ====================

// Hook 可能存在的其他验证属性
%hook NSObject

// 拦截所有以 has/is/check 开头的 BOOL 方法
- (BOOL)hasUnlockedSuccessfully {
    if ([self isKindOfClass:NSClassFromString(@"WCRefineAuth")] ||
        [self isKindOfClass:NSClassFromString(@"WCRefineManager")]) {
        NSLog(@"[WCRefineBypass] NSObject hasUnlockedSuccessfully - returning YES");
        return YES;
    }
    return %orig;
}

- (BOOL)hasSponsored {
    if ([self isKindOfClass:NSClassFromString(@"WCRefineAuth")]) {
        return YES;
    }
    return %orig;
}

%end

// ==================== 网络请求拦截 ====================

// Hook NSURLSession 拦截验证请求
%hook NSURLSession

- (NSURLSessionDataTask *)dataTaskWithRequest:(NSURLRequest *)request 
                            completionHandler:(void (^)(NSData *, NSURLResponse *, NSError *))completionHandler {
    
    NSURL *url = request.URL;
    
    // 拦截 w277.com 的验证请求
    if ([url.host containsString:@"w277.com"] || 
        [url.host containsString:@"sutuplus.vip"] ||
        [url.path containsString:@"exchange"] ||
        [url.path containsString:@"auth"]) {
        
        NSLog(@"[WCRefineBypass] Intercepted request to: %@", url.absoluteString);
        
        // 构造假的成功响应
        NSString *fakeJSON = @"{\"success\":true,\"code\":200,\"message\":\"ok\",\"data\":{\"valid\":true,\"vip\":true,\"expired\":false}}";
        NSData *fakeData = [fakeJSON dataUsingEncoding:NSUTF8StringEncoding];
        
        NSHTTPURLResponse *fakeResponse = [[NSHTTPURLResponse alloc] initWithURL:url
                                                                        statusCode:200
                                                                       HTTPVersion:@"HTTP/1.1"
                                                                      headerFields:@{@"Content-Type": @"application/json"}];
        
        // 直接返回假数据
        if (completionHandler) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completionHandler(fakeData, fakeResponse, nil);
            });
        }
        
        // 返回一个假的 task
        return %orig(request, nil);
    }
    
    return %orig(request, completionHandler);
}

%end

// ==================== 构造函数 ====================

%ctor {
    NSLog(@"[WCRefineBypass] Tweak loaded!");
    
    // 延迟执行，等待 WCRefine 加载完成
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        // 尝试获取单例并强制解锁
        Class authClass = NSClassFromString(@"WCRefineAuth");
        if (authClass) {
            NSLog(@"[WCRefineBypass] Found WCRefineAuth class");
            
            id sharedInstance = [authClass performSelector:@selector(sharedInstance)];
            if (sharedInstance) {
                NSLog(@"[WCRefineBypass] Got sharedInstance, forcing unlock");
                
                // 强制设置解锁状态
                [sharedInstance setValue:@YES forKey:@"hasUnlockedSuccessfully"];
                [sharedInstance setValue:@YES forKey:@"hasSponsored"];
                [sharedInstance setValue:@YES forKey:@"_hasUnlockedSuccessfully"];
                [sharedInstance setValue:@YES forKey:@"_hasSponsored"];
            }
        }
        
        // 同样处理 Manager
        Class managerClass = NSClassFromString(@"WCRefineManager");
        if (managerClass) {
            id sharedManager = [managerClass performSelector:@selector(sharedManager)];
            if (sharedManager) {
                NSLog(@"[WCRefineBypass] Got sharedManager");
            }
        }
    });
}
