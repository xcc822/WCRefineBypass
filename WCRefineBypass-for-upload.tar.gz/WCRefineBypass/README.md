# WCRefineBypass

绕过 WCRefine 微信插件的内测验证机制。

## 原理

通过以下方式绕过验证：
1. **Hook WCRefineAuth 类** - 强制返回已解锁/已赞助状态
2. **Hook 网络请求** - 拦截 w277.com 验证请求，返回伪造的成功响应
3. **运行时修改** - 延迟修改验证状态

## 编译安装

### 环境要求
- macOS 或 Linux（with theos）
- Xcode Command Line Tools
- theos 工具链

### 编译步骤

```bash
# 1. 确保安装了 theos
export THEOS=~/theos

# 2. 进入项目目录
cd /path/to/WCRefineBypass

# 3. 编译
clean && make package

# 4. 安装到设备
make install
```

### 手动打包

如果没有 theos 环境，可以手动打包：

```bash
# 创建目录结构
mkdir -p wcrefinebypass/DEBIAN
mkdir -p wcrefinebypass/var/jb/Library/MobileSubstrate/DynamicLibraries

# 复制文件
cp control wcrefinebypass/DEBIAN/
cp WCRefineBypass.plist wcrefinebypass/var/jb/Library/MobileSubstrate/DynamicLibraries/
cp .theos/obj/debug/WCRefineBypass.dylib wcrefinebypass/var/jb/Library/MobileSubstrate/DynamicLibraries/

# 打包
dpkg-deb -b wcrefinebypass WCRefineBypass_1.0.0_iphoneos-arm64.deb
```

## 文件说明

| 文件 | 说明 |
|------|------|
| `Tweak.x` | 主 tweak 代码 |
| `AdvancedHook.x` | 高级 hook 示例（使用 MSHookMessageEx）|
| `control` | Debian 包控制信息 |
| `WCRefineBypass.plist` | 过滤配置（只注入微信）|
| `Makefile` | 编译配置 |

## Hook 的类和方法

### WCRefineAuth
- `hasUnlockedSuccessfully` → 强制返回 YES
- `hasSponsored` → 强制返回 YES  
- `biometricUnlockEnabled` → 强制返回 YES
- `checkAuth` → 强制返回 YES
- `isValid` → 强制返回 YES
- `verifyWithCompletion:` → 拦截并调用成功回调

### WCRefineManager
- `isFeatureUnlocked:` → 强制返回 YES
- `hasValidLicense` → 强制返回 YES
- `checkLicenseStatus` → 强制返回 YES

### NSURLSession
- `dataTaskWithRequest:completionHandler:` → 拦截 w277.com 请求

## 验证是否生效

安装后查看系统日志：

```bash
# 在 iOS 设备上
idevicesyslog | grep "WCRefineBypass"

# 或者通过 Xcode
Console.app → 连接设备 → 搜索 "WCRefineBypass"
```

看到以下日志说明生效：
```
[WCRefineBypass] Tweak loaded!
[WCRefineBypass] hasUnlockedSuccessfully hooked - returning YES
[WCRefineBypass] Intercepted request to: https://app.w277.com/...
```

## 故障排除

### 1. 插件不生效
- 检查 `WCRefineBypass.plist` 中的 Bundle ID 是否正确
- 确认 dylib 文件权限：`chmod 755 WCRefineBypass.dylib`
- 重启微信或重新越狱

### 2. 崩溃问题
- 可能是类名不匹配，用 `class-dump` 确认 WCRefine 的实际类名
- 检查是否有其他 tweak 冲突

### 3. 验证仍弹窗
- 可能需要 hook 更多的验证方法
- 检查网络请求是否被其他插件拦截

## 进阶调试

### 使用 Frida 动态分析

```javascript
// frida_script.js
// 列出 WCRefine 的所有类和方法

var WCRefineAuth = ObjC.classes.WCRefineAuth;
if (WCRefineAuth) {
    console.log("[+] Found WCRefineAuth");
    
    // 列出所有方法
    var methods = WCRefineAuth.$ownMethods;
    methods.forEach(function(method) {
        console.log("  - " + method);
    });
    
    // Hook 具体方法
    Interceptor.attach(WCRefineAuth["- hasUnlockedSuccessfully"].implementation, {
        onLeave: function(retval) {
            console.log("[*] hasUnlockedSuccessfully returned: " + retval);
            retval.replace(0x1); // 强制返回 YES
        }
    });
}
```

运行：
```bash
frida -U -n WeChat -l frida_script.js
```

## 免责声明

本工具仅供学习研究使用，请支持正版软件。

## 更新日志

### v1.0.0
- 初始版本
- 支持绕过 WCRefine 1.4-1beta2 验证
