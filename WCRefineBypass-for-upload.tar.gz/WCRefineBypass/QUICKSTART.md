# WCRefineBypass 快速开始指南

## 📦 文件说明

| 文件 | 用途 |
|------|------|
| `Tweak.x` | 主 Tweak 代码，使用 Logos 语法 |
| `Makefile` | theos 编译配置 |
| `control` | Debian 包信息 |
| `WCRefineBypass.plist` | 注入目标配置（只注入微信） |
| `wcrefine_analyzer.js` | Frida 动态调试脚本 |
| `build.sh` | 自动编译脚本 |

## 🚀 三种使用方式

### 方式 1：自己编译（推荐）

```bash
cd WCRefineBypass

# 设置 theos 路径
export THEOS=~/theos

# 编译
make clean
make package

# 安装到设备
make install
```

### 方式 2：手动打包（无编译环境）

如果你有其他人编译好的 `WCRefineBypass.dylib`：

```bash
cd prebuilt_deb

# 将 dylib 放入对应目录
cp /path/to/WCRefineBypass.dylib \
   var/jb/Library/MobileSubstrate/DynamicLibraries/

# 打包
dpkg-deb -b . ../WCRefineBypass_1.0.0_iphoneos-arm64.deb

# 安装到设备
dpkg -i WCRefineBypass_1.0.0_iphoneos-arm64.deb
killall -9 SpringBoard
```

### 方式 3：Frida 临时注入（免越狱/测试用）

```bash
# 1. 启动 Frida Server（设备上）

# 2. 运行分析脚本
frida -U -n WeChat -l wcrefine_analyzer.js

# 3. 在 Frida REPL 中执行解锁
[Local::WeChat]-> rpc.exports.forceUnlock()
```

## 🔧 关键 Hook 点

```logos
%hook WCRefineAuth
- (BOOL)hasUnlockedSuccessfully { return YES; }
- (BOOL)hasSponsored { return YES; }
- (BOOL)checkAuth { return YES; }
%end
```

## 📝 调试技巧

### 查看日志

```bash
# 方法1: 设备上直接看
tail -f /var/log/syslog | grep WCRefineBypass

# 方法2: 通过 USB
devicesyslog | grep WCRefineBypass

# 方法3: Xcode Console
# 连接设备，打开 Console.app，过滤 "WCRefineBypass"
```

### 验证是否生效

1. 打开微信
2. 进入 WCRefine 设置
3. 查看是否显示"已解锁"/"已赞助"
4. 检查系统日志是否有 `[WCRefineBypass]` 输出

## ⚠️ 常见问题

### Q: 编译报错 "theos not found"
```bash
# 安装 theos
bash -c "$(curl -fsSL https://raw.githubusercontent.com/theos/theos/master/bin/install-theos)"
```

### Q: 安装后微信闪退
- 检查 `WCRefineBypass.plist` 中的 Bundle ID
- 可能是类名不匹配，用 Frida 脚本确认实际类名
- 尝试移除部分 hook，定位冲突

### Q: 验证仍然弹窗
- 用 Frida 脚本分析是否还有其他验证类
- 检查网络请求是否被其他插件拦截
- 可能需要 hook 更多方法（如 `isHideMyPagePluginEncryptedActive`）

### Q: 如何找到正确的类名
```javascript
// Frida 脚本
for (var c in ObjC.classes) {
    if (c.toLowerCase().includes("auth") || 
        c.toLowerCase().includes("verify")) {
        console.log(c);
    }
}
```

## 🎯 进阶修改

### 修改验证服务器地址
在 `Tweak.x` 中搜索 `w277.com`，可以修改为本地代理地址：

```logos
// 原始
if ([url.host containsString:@"w277.com"])

// 修改为本地代理
if ([url.host containsString:@"w277.com"] || 
    [url.host containsString:@"192.168.2.1"])
```

### 添加更多验证绕过
如果发现新的验证方法，添加到 `Tweak.x`：

```logos
%hook NewAuthClass
- (BOOL)isNewCheckMethod {
    return YES;
}
%end
```

## 📚 参考资源

- [theos 文档](https://theos.dev/docs/)
- [Logos 语法](https://theos.dev/docs/logos-syntax)
- [Frida iOS 教程](https://frida.re/docs/ios/)
- [iOS 逆向工程](https://github.com/AloneMonkey/iOSREBook)

## 💡 提示

本 tweak 仅供学习研究，请支持正版软件。
WCRefine 是优秀的微信插件，有能力请支持作者！
