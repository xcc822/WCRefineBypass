// Frida 动态调试脚本 - 用于分析 WCRefine 验证机制
// 使用方法: frida -U -n WeChat -l wcrefine_analyzer.js

console.log("[*] WCRefine Analyzer loaded");

// ==================== 工具函数 ====================

function enumerateMethods(className) {
    var cls = ObjC.classes[className];
    if (!cls) {
        console.log("[-] Class " + className + " not found");
        return [];
    }
    
    var methods = cls.$ownMethods;
    console.log("[+] " + className + " has " + methods.length + " methods:");
    methods.forEach(function(m) {
        console.log("    - " + m);
    });
    return methods;
}

function hookMethod(className, methodName, onEnter, onLeave) {
    var cls = ObjC.classes[className];
    if (!cls) {
        console.log("[-] Cannot hook " + className + ", class not found");
        return;
    }
    
    var selector = methodName.startsWith("-") ? methodName.substring(2) : methodName;
    var fullName = methodName.startsWith("-") ? "- " + selector : "+ " + selector;
    
    try {
        var imp = cls[fullName].implementation;
        Interceptor.attach(imp, {
            onEnter: function(args) {
                console.log("[HOOK] " + className + " " + fullName + " called");
                if (onEnter) onEnter(args);
            },
            onLeave: function(retval) {
                if (onLeave) onLeave(retval);
            }
        });
        console.log("[+] Hooked " + className + " " + fullName);
    } catch(e) {
        console.log("[-] Failed to hook " + className + " " + fullName + ": " + e);
    }
}

// ==================== 主逻辑 ====================

// 等待应用加载完成
setTimeout(function() {
    
    console.log("\n[*] ====== WCRefine 分析开始 ======\n");
    
    // 1. 查找 WCRefine 相关类
    var allClasses = ObjC.classes;
    var wcrefineClasses = [];
    
    for (var className in allClasses) {
        if (className.toLowerCase().includes("wcrefine") || 
            className.toLowerCase().includes("pj") ||
            className.toLowerCase().includes("sponsor")) {
            wcrefineClasses.push(className);
        }
    }
    
    console.log("[+] Found " + wcrefineClasses.length + " WCRefine related classes:");
    wcrefineClasses.forEach(function(c) {
        console.log("    - " + c);
    });
    
    // 2. 详细分析 WCRefineAuth
    console.log("\n[*] ====== WCRefineAuth 详细分析 ======\n");
    
    var authMethods = enumerateMethods("WCRefineAuth");
    
    // Hook 关键的 BOOL 返回值方法
    var boolMethods = authMethods.filter(function(m) {
        return m.includes("Unlocked") || 
               m.includes("Sponsor") || 
               m.includes("Valid") ||
               m.includes("Auth") ||
               m.includes("Enable") ||
               m.includes("Check");
    });
    
    console.log("\n[*] Key boolean methods to hook:");
    boolMethods.forEach(function(m) {
        console.log("    - " + m);
        
        // 自动 hook 并修改返回值
        hookMethod("WCRefineAuth", m, null, function(retval) {
            console.log("    [RETURN] " + m + " = " + retval);
            retval.replace(0x1);
            console.log("    [PATCHED] " + m + " = 1");
        });
    });
    
    // 3. 分析 WCRefineManager
    console.log("\n[*] ====== WCRefineManager 分析 ======\n");
    enumerateMethods("WCRefineManager");
    
    // 4. 拦截网络请求
    console.log("\n[*] ====== 网络请求监控 ======\n");
    
    var NSURLSession = ObjC.classes.NSURLSession;
    if (NSURLSession) {
        Interceptor.attach(NSURLSession["- dataTaskWithRequest:completionHandler:"].implementation, {
            onEnter: function(args) {
                var request = ObjC.Object(args[2]);
                var url = request.URL().absoluteString();
                
                if (url.toString().includes("w277") || 
                    url.toString().includes("sutuplus") ||
                    url.toString().includes("auth")) {
                    console.log("[NETWORK] Intercepted: " + url);
                    
                    // 打印请求头
                    var headers = request.allHTTPHeaderFields();
                    console.log("[NETWORK] Headers: " + headers);
                }
            }
        });
    }
    
    // 5. 获取验证状态
    console.log("\n[*] ====== 当前验证状态 ======\n");
    
    var WCRefineAuth = ObjC.classes.WCRefineAuth;
    if (WCRefineAuth) {
        var shared = WCRefineAuth["+ sharedInstance"]();
        if (shared) {
            console.log("[+] Got WCRefineAuth sharedInstance");
            
            // 尝试调用各种验证方法
            try {
                var hasUnlocked = shared["- hasUnlockedSuccessfully"]();
                console.log("[*] hasUnlockedSuccessfully: " + hasUnlocked);
            } catch(e) {}
            
            try {
                var hasSponsored = shared["- hasSponsored"]();
                console.log("[*] hasSponsored: " + hasSponsored);
            } catch(e) {}
        }
    }
    
    console.log("\n[*] ====== 分析完成 ======\n");
    
}, 3000);

// ==================== 交互命令 ====================

// 可以通过 Frida REPL 调用的函数
rpc.exports = {
    // 列出所有类
    listClasses: function() {
        var classes = [];
        for (var c in ObjC.classes) {
            if (c.toLowerCase().includes("wcrefine")) {
                classes.push(c);
            }
        }
        return classes;
    },
    
    // 列出类的方法
    listMethods: function(className) {
        var cls = ObjC.classes[className];
        if (!cls) return [];
        return cls.$ownMethods;
    },
    
    // 强制解锁
    forceUnlock: function() {
        var WCRefineAuth = ObjC.classes.WCRefineAuth;
        if (!WCRefineAuth) return "WCRefineAuth not found";
        
        var shared = WCRefineAuth["+ sharedInstance"]();
        if (!shared) return "sharedInstance is null";
        
        // 使用 KVC 设置值
        shared.setValue_forKey_(1, "hasUnlockedSuccessfully");
        shared.setValue_forKey_(1, "hasSponsored");
        
        return "Force unlock executed";
    },
    
    // 检查当前状态
    checkStatus: function() {
        var result = {};
        var WCRefineAuth = ObjC.classes.WCRefineAuth;
        
        if (WCRefineAuth) {
            var shared = WCRefineAuth["+ sharedInstance"]();
            if (shared) {
                try {
                    result.hasUnlocked = shared["- hasUnlockedSuccessfully"]().toString();
                } catch(e) {
                    result.hasUnlocked = "error: " + e;
                }
                
                try {
                    result.hasSponsored = shared["- hasSponsored"]().toString();
                } catch(e) {
                    result.hasSponsored = "error: " + e;
                }
            } else {
                result.error = "sharedInstance is null";
            }
        } else {
            result.error = "WCRefineAuth not found";
        }
        
        return result;
    }
};
