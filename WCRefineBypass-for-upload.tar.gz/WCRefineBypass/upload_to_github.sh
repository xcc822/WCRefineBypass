#!/bin/bash

# 一键上传并触发 GitHub Actions 编译
# 用法: ./upload_to_github.sh 你的GitHub用户名

set -e

GITHUB_USER="${1:-}"
REPO_NAME="WCRefineBypass"

if [ -z "$GITHUB_USER" ]; then
    echo "❌ 请提供 GitHub 用户名"
    echo "用法: $0 <GitHub用户名>"
    echo "示例: $0 yourname"
    exit 1
fi

echo "🚀 WCRefineBypass GitHub Actions 一键部署"
echo "=========================================="
echo ""

# 检查 git
if ! command -v git &> /dev/null; then
    echo "❌ 请先安装 git"
    exit 1
fi

# 检查 gh CLI（可选）
USE_GH=false
if command -v gh &> /dev/null; then
    USE_GH=true
    echo "✅ 检测到 GitHub CLI"
else
    echo "⚠️  未检测到 GitHub CLI，将使用 git 命令"
    echo "   建议安装: https://cli.github.com/"
fi

echo ""
echo "📁 准备上传文件..."

# 初始化 git（如果没有）
if [ ! -d ".git" ]; then
    git init
    git branch -M main
fi

# 添加所有文件
git add .

# 检查是否有变更
if git diff --cached --quiet; then
    echo "⚠️  没有新变更需要提交"
else
    git commit -m "Update WCRefineBypass - $(date '+%Y-%m-%d %H:%M:%S')"
    echo "✅ 已提交变更"
fi

# 设置远程仓库
REMOTE_URL="https://github.com/${GITHUB_USER}/${REPO_NAME}.git"

if git remote get-url origin &> /dev/null; then
    echo "📝 更新远程仓库地址: $REMOTE_URL"
    git remote set-url origin "$REMOTE_URL"
else
    echo "📝 添加远程仓库: $REMOTE_URL"
    git remote add origin "$REMOTE_URL"
fi

echo ""
echo "📤 推送到 GitHub..."

# 推送
if git push -u origin main; then
    echo "✅ 推送成功！"
else
    echo ""
    echo "❌ 推送失败，可能原因:"
    echo "   1. 仓库不存在，请先创建: https://github.com/new"
    echo "   2. 没有权限，请检查用户名或 Token"
    echo "   3. 网络问题"
    echo ""
    echo "💡 手动创建仓库步骤:"
    echo "   1. 打开 https://github.com/new"
    echo "   2. 输入仓库名: $REPO_NAME"
    echo "   3. 选择 Public 或 Private"
    echo "   4. 不要勾选 README"
    echo "   5. 点击 Create repository"
    exit 1
fi

echo ""
echo "🎉 完成！下一步:"
echo ""
echo "   1. 打开 https://github.com/${GITHUB_USER}/${REPO_NAME}/actions"
echo "   2. 点击 'Build WCRefineBypass'"
echo "   3. 点击 'Run workflow' → 'Run workflow'"
echo "   4. 等待 2-3 分钟"
echo "   5. 下载编译好的 .deb"
echo ""

# 如果用 gh CLI，可以直接打开浏览器
if [ "$USE_GH" = true ]; then
    echo "🌐 正在打开 Actions 页面..."
    gh workflow view --web 2>/dev/null || true
fi

echo "✨ 祝使用愉快！"
