#!/bin/bash

# 快速安装脚本 - 将 deb 安装到已越狱的 iOS 设备

DEVICE_IP=$1

if [ -z "$DEVICE_IP" ]; then
    echo "Usage: $0 <device-ip>"
    echo "Example: $0 192.168.1.100"
    exit 1
fi

DEB_FILE=$(ls -t *.deb 2>/dev/null | head -1)

if [ -z "$DEB_FILE" ]; then
    echo "Error: No .deb file found in current directory"
    exit 1
fi

echo "Installing $DEB_FILE to $DEVICE_IP..."

# 复制到设备
scp "$DEB_FILE" root@$DEVICE_IP:/tmp/

# 安装并重启 SpringBoard
ssh root@$DEVICE_IP "dpkg -i /tmp/$(basename $DEB_FILE) && killall -9 SpringBoard"

echo "Done!"
